# Guia de Execução do Banco de Dados — Sistema de Gestão para Salão

Este documento explica como executar o script **salon_system.sql** no MySQL e preparar o ambiente para uso.

---

## 📌 1. Pré‑requisitos

Antes de começar, você precisa ter instalado:

- **MySQL Server** (versão 5.7+ ou 8.x)
- **MySQL Workbench**, DBeaver ou outro cliente SQL (opcional)
- O arquivo: `salon_system.sql`

---

## 📌 2. Criando o Banco de Dados

O script já contém:

```sql
CREATE DATABASE IF NOT EXISTS salon_db
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE salon_db;
```

Isso significa que **você não precisa criar o banco manualmente** — o script fará isso.

---

## 📌 3. Executando o Script

### 🔹 Opção 1 — Usando MySQL Workbench

1. Abra o MySQL Workbench  
2. Clique em **File → Open Script**  
3. Selecione o arquivo `salon_system.sql`  
4. Clique em **Execute (⚡)**  
5. Verifique se o banco `salon_db` foi criado na barra lateral

---

### 🔹 Opção 2 — Usando terminal / cmd / PowerShell

1. Navegue até a pasta onde está o arquivo:

```bash
cd caminho/da/pasta/
```

2. Rode o comando:

```bash
mysql -u root -p < salon_system.sql
```

3. Digite sua senha quando solicitado.

---

## 📌 4. Verificando as tabelas

Após importar, execute:

```sql
USE salon_db;
SHOW TABLES;
```

Você deverá ver:

- cliente  
- usuario  
- servico  
- agendamento  
- pagamento  
- produto  
- movimentacao_estoque  
- frequencia_cliente  

---

## 📌 5. Testando uma consulta simples

```sql
SELECT * FROM cliente;
```

Caso ainda não tenha cadastros, o resultado estará vazio — isso é normal.

---

## 📌 6. Inserindo um cliente de exemplo

```sql
INSERT INTO cliente (nome, telefone, email)
VALUES ('Maria Silva', '31988887777', 'maria@gmail.com');
```

---

## 📌 7. Criando um usuário para o sistema

```sql
INSERT INTO usuario (nome, login, senha, perfil)
VALUES ('Admin', 'admin', '1234', 'DONA');
```

⚠️ *A senha deve ser criptografada na aplicação (ex: bcrypt).*

---

## 📌 8. Limpando tudo (caso necessário)

Se quiser apagar o banco:

```sql
DROP DATABASE salon_db;
```

---

## 📌 9. Próximos passos recomendados

- Criar interface (web/mobile)
- Configurar API para agendamentos e lembretes automáticos
- Criar dashboards para relatórios financeiros
- Implementar autenticação com JWT ou Spring Security

---

## ✔ Pronto! Banco configurado.

Se quiser, posso gerar:
✅ Um **diagrama ERD visual**  
✅ Um **script com INSERTs reais para testes**  
✅ A **API completa em Spring Boot**  
