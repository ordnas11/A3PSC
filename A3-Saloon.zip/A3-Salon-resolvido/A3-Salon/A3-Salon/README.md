Salon Management - Spring Boot (generated)
========================================

How to run:
1. Edit src/main/resources/application.properties and set your MySQL credentials.
2. Create database: `CREATE DATABASE salon_db;`
3. Build: mvn clean package
4. Run: mvn spring-boot:run

Notes:
- Uses Flyway for initial schema (src/main/resources/db/migration/V1__init.sql).
- OpenAPI UI available at /swagger-ui.html (springdoc).
