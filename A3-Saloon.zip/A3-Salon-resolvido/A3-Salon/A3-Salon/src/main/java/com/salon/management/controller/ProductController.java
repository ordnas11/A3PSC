package com.salon.management.controller;

import com.salon.management.dto.ProductDto;
import com.salon.management.entity.Product;
import com.salon.management.service.ProductService;
import com.salon.management.util.MapperUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/products")
public class ProductController {
    private final ProductService service;
    public ProductController(ProductService service){ this.service = service; }

    @GetMapping
    public List<ProductDto> all(){ return service.findAll().stream().map(MapperUtil::toProductDto).collect(Collectors.toList()); }

    @GetMapping("/{id}")
    public ResponseEntity<ProductDto> get(@PathVariable Long id){
        return service.findById(id).map(p -> ResponseEntity.ok(MapperUtil.toProductDto(p)))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ProductDto> create(@RequestBody ProductDto dto){
        Product saved = service.save(MapperUtil.toProductEntity(dto));
        return ResponseEntity.created(URI.create("/api/products/" + saved.getId())).body(MapperUtil.toProductDto(saved));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ProductDto> update(@PathVariable Long id, @RequestBody ProductDto dto){
        return service.findById(id).map(existing -> {
            existing.setName(dto.getName());
            existing.setSku(dto.getSku());
            existing.setPrice(dto.getPrice());
            existing.setQuantity(dto.getQuantity());
            Product updated = service.save(existing);
            return ResponseEntity.ok(MapperUtil.toProductDto(updated));
        }).orElse(ResponseEntity.notFound().build());
    }

    @PatchMapping("/{id}/adjust")
    public ResponseEntity<ProductDto> adjust(@PathVariable Long id, @RequestParam int delta){
        Product updated = service.adjustQuantity(id, delta);
        return ResponseEntity.ok(MapperUtil.toProductDto(updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){
        service.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
