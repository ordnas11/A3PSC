package com.salon.management.service;

import com.salon.management.entity.ServiceProcedure;
import com.salon.management.repository.ServiceRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ServiceProcedureService {
    private final ServiceRepository repo;
    public ServiceProcedureService(ServiceRepository repo){ this.repo = repo; }

    public List<ServiceProcedure> findAll(){ return repo.findAll(); }
    public Optional<ServiceProcedure> findById(Long id){ return repo.findById(id); }
    public ServiceProcedure save(ServiceProcedure s){ return repo.save(s); }
    public void deleteById(Long id){ repo.deleteById(id); }
}
