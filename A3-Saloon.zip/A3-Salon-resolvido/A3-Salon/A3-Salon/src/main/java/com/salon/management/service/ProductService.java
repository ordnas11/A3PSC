package com.salon.management.service;

import com.salon.management.entity.Product;
import com.salon.management.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {
    private final ProductRepository repo;
    public ProductService(ProductRepository repo){ this.repo = repo; }

    public List<Product> findAll(){ return repo.findAll(); }
    public Optional<Product> findById(Long id){ return repo.findById(id); }
    public Product save(Product p){ return repo.save(p); }

    public Product adjustQuantity(Long productId, int delta){
        Product p = repo.findById(productId).orElseThrow(() -> new RuntimeException("Produto não encontrado"));
        int newQ = (p.getQuantity() == null ? 0 : p.getQuantity()) + delta;
        if(newQ < 0) throw new RuntimeException("Quantidade insuficiente em estoque");
        p.setQuantity(newQ);
        return repo.save(p);
    }

    public void deleteById(Long id){ repo.deleteById(id); }
}
