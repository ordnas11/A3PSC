package com.salon.management.controller;

import com.salon.management.dto.ServiceDto;
import com.salon.management.entity.ServiceProcedure;
import com.salon.management.service.ServiceProcedureService;
import com.salon.management.util.MapperUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/services")
public class ServiceController {
    private final ServiceProcedureService service;
    public ServiceController(ServiceProcedureService service){ this.service = service; }

    @GetMapping
    public List<ServiceDto> all(){ return service.findAll().stream().map(MapperUtil::toServiceDto).collect(Collectors.toList()); }

    @GetMapping("/{id}")
    public ResponseEntity<ServiceDto> get(@PathVariable Long id){
        return service.findById(id).map(s -> ResponseEntity.ok(MapperUtil.toServiceDto(s)))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ServiceDto> create(@RequestBody ServiceDto dto){
        ServiceProcedure saved = service.save(MapperUtil.toServiceEntity(dto));
        return ResponseEntity.created(URI.create("/api/services/" + saved.getId())).body(MapperUtil.toServiceDto(saved));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ServiceDto> update(@PathVariable Long id, @RequestBody ServiceDto dto){
        return service.findById(id).map(existing -> {
            existing.setName(dto.getName());
            existing.setDescription(dto.getDescription());
            existing.setDurationMinutes(dto.getDurationMinutes());
            existing.setPrice(dto.getPrice());
            ServiceProcedure updated = service.save(existing);
            return ResponseEntity.ok(MapperUtil.toServiceDto(updated));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){
        service.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
