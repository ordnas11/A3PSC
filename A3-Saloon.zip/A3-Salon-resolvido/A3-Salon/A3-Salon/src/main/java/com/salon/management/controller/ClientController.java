package com.salon.management.controller;

import com.salon.management.dto.ClientDto;
import com.salon.management.entity.Client;
import com.salon.management.service.ClientService;
import com.salon.management.util.MapperUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/clients")
public class ClientController {
    private final ClientService service;
    public ClientController(ClientService service){ this.service = service; }

    @GetMapping
    public List<ClientDto> getAll(){
        return service.findAll().stream().map(MapperUtil::toClientDto).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ClientDto> getById(@PathVariable Long id){
        return service.findById(id).map(c -> ResponseEntity.ok(MapperUtil.toClientDto(c)))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ClientDto> create(@RequestBody ClientDto dto){
        Client saved = service.save(MapperUtil.toClientEntity(dto));
        return ResponseEntity.created(URI.create("/api/clients/" + saved.getId()))
                .body(MapperUtil.toClientDto(saved));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ClientDto> update(@PathVariable Long id, @RequestBody ClientDto dto){
        return service.findById(id).map(existing -> {
            existing.setName(dto.getName());
            existing.setPhone(dto.getPhone());
            existing.setEmail(dto.getEmail());
            existing.setNotes(dto.getNotes());
            Client updated = service.save(existing);
            return ResponseEntity.ok(MapperUtil.toClientDto(updated));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){
        service.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
