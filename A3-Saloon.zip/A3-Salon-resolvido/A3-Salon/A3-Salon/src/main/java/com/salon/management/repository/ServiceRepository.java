package com.salon.management.repository;

import com.salon.management.entity.ServiceProcedure;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ServiceRepository extends JpaRepository<ServiceProcedure, Long> {
}
