package com.salon.management.controller;

import com.salon.management.dto.AppointmentDto;
import com.salon.management.entity.Appointment;
import com.salon.management.service.AppointmentService;
import com.salon.management.util.MapperUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController {

    private final AppointmentService appointmentService;
    public AppointmentController(AppointmentService appointmentService){
        this.appointmentService = appointmentService;
    }

    @GetMapping
    public List<AppointmentDto> all(){
        return appointmentService.findAll().stream().map(MapperUtil::toAppointmentDto).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<AppointmentDto> get(@PathVariable Long id){
        return appointmentService.findById(id).map(a -> ResponseEntity.ok(MapperUtil.toAppointmentDto(a))).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<AppointmentDto> create(@RequestBody AppointmentDto dto){
        Appointment a = appointmentService.scheduleAppointment(dto.getClientId(), dto.getServiceId(), dto.getAppointmentDatetime(), dto.getNotes());
        return ResponseEntity.created(URI.create("/api/appointments/" + a.getId())).body(MapperUtil.toAppointmentDto(a));
    }

    @PutMapping("/{id}")
    public ResponseEntity<AppointmentDto> update(@PathVariable Long id, @RequestBody AppointmentDto dto){
        return appointmentService.findById(id).map(existing -> {
            existing.setAppointmentDatetime(dto.getAppointmentDatetime());
            existing.setNotes(dto.getNotes());
            existing.setStatus(dto.getStatus() == null ? existing.getStatus() : dto.getStatus());
            Appointment updated = appointmentService.update(existing);
            return ResponseEntity.ok(MapperUtil.toAppointmentDto(updated));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){
        appointmentService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/cancel")
    public ResponseEntity<Void> cancel(@PathVariable Long id){
        appointmentService.cancel(id);
        return ResponseEntity.noContent().build();
    }
}
