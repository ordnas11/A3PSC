package com.salon.management.util;

import com.salon.management.dto.*;
import com.salon.management.entity.*;

public class MapperUtil {

    public static ClientDto toClientDto(Client c){
        if(c == null) return null;
        ClientDto dto = new ClientDto();
        dto.setId(c.getId());
        dto.setName(c.getName());
        dto.setPhone(c.getPhone());
        dto.setEmail(c.getEmail());
        dto.setNotes(c.getNotes());
        return dto;
    }

    public static Client toClientEntity(ClientDto dto){
        if(dto == null) return null;
        Client c = new Client();
        c.setId(dto.getId());
        c.setName(dto.getName());
        c.setPhone(dto.getPhone());
        c.setEmail(dto.getEmail());
        c.setNotes(dto.getNotes());
        return c;
    }

    public static ServiceDto toServiceDto(ServiceProcedure s){
        if(s==null) return null;
        ServiceDto dto = new ServiceDto();
        dto.setId(s.getId());
        dto.setName(s.getName());
        dto.setDescription(s.getDescription());
        dto.setDurationMinutes(s.getDurationMinutes());
        dto.setPrice(s.getPrice());
        return dto;
    }

    public static ServiceProcedure toServiceEntity(ServiceDto dto){
        if(dto==null) return null;
        ServiceProcedure s = new ServiceProcedure();
        s.setId(dto.getId());
        s.setName(dto.getName());
        s.setDescription(dto.getDescription());
        s.setDurationMinutes(dto.getDurationMinutes());
        s.setPrice(dto.getPrice());
        return s;
    }

    public static ProductDto toProductDto(Product p){
        if(p==null) return null;
        ProductDto dto = new ProductDto();
        dto.setId(p.getId());
        dto.setName(p.getName());
        dto.setSku(p.getSku());
        dto.setQuantity(p.getQuantity());
        dto.setPrice(p.getPrice());
        return dto;
    }

    public static Product toProductEntity(ProductDto dto){
        if(dto==null) return null;
        Product p = new Product();
        p.setId(dto.getId());
        p.setName(dto.getName());
        p.setSku(dto.getSku());
        p.setQuantity(dto.getQuantity());
        p.setPrice(dto.getPrice());
        return p;
    }

    public static AppointmentDto toAppointmentDto(Appointment a){
        if(a==null) return null;
        AppointmentDto dto = new AppointmentDto();
        dto.setId(a.getId());
        dto.setClientId(a.getClient() != null ? a.getClient().getId() : null);
        dto.setServiceId(a.getServiceProcedure() != null ? a.getServiceProcedure().getId() : null);
        dto.setAppointmentDatetime(a.getAppointmentDatetime());
        dto.setNotes(a.getNotes());
        dto.setStatus(a.getStatus());
        return dto;
    }

    public static Appointment toAppointmentEntity(AppointmentDto dto, Client client, ServiceProcedure service){
        if(dto==null) return null;
        Appointment a = new Appointment();
        a.setId(dto.getId());
        a.setClient(client);
        a.setServiceProcedure(service);
        a.setAppointmentDatetime(dto.getAppointmentDatetime());
        a.setNotes(dto.getNotes());
        a.setStatus(dto.getStatus() == null ? "SCHEDULED" : dto.getStatus());
        return a;
    }
}
