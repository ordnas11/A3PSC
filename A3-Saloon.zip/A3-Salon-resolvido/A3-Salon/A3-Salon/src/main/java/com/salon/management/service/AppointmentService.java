package com.salon.management.service;

import com.salon.management.entity.Appointment;
import com.salon.management.entity.Client;
import com.salon.management.entity.ServiceProcedure;
import com.salon.management.repository.AppointmentRepository;
import com.salon.management.repository.ClientRepository;
import com.salon.management.repository.ServiceRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class AppointmentService {
    private final AppointmentRepository appointmentRepo;
    private final ClientRepository clientRepo;
    private final ServiceRepository serviceRepo;

    public AppointmentService(AppointmentRepository appointmentRepo, ClientRepository clientRepo, ServiceRepository serviceRepo){
        this.appointmentRepo = appointmentRepo;
        this.clientRepo = clientRepo;
        this.serviceRepo = serviceRepo;
    }

    public List<Appointment> findAll(){ return appointmentRepo.findAll(); }
    public Optional<Appointment> findById(Long id){ return appointmentRepo.findById(id); }

    @Transactional
    public Appointment scheduleAppointment(Long clientId, Long serviceId, LocalDateTime dateTime, String notes){
        if(appointmentRepo.existsByAppointmentDatetime(dateTime)){
            throw new RuntimeException("Horário já agendado");
        }
        Client c = clientRepo.findById(clientId).orElseThrow(() -> new RuntimeException("Cliente não encontrado"));
        ServiceProcedure s = serviceRepo.findById(serviceId).orElseThrow(() -> new RuntimeException("Serviço não encontrado"));

        Appointment a = new Appointment();
        a.setClient(c);
        a.setServiceProcedure(s);
        a.setAppointmentDatetime(dateTime);
        a.setNotes(notes);
        a.setStatus("SCHEDULED");
        return appointmentRepo.save(a);
    }

    public Appointment update(Appointment ap){
        return appointmentRepo.save(ap);
    }

    public void cancel(Long id){
        Appointment a = appointmentRepo.findById(id).orElseThrow(() -> new RuntimeException("Agendamento não encontrado"));
        a.setStatus("CANCELLED");
        appointmentRepo.save(a);
    }

    public void delete(Long id){
        appointmentRepo.deleteById(id);
    }
}
