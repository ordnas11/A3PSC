package com.salon.management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalonManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(SalonManagementApplication.class, args);
    }
}
